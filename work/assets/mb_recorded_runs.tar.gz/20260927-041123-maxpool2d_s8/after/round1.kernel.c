// idea: process two output rows per inner loop, load once, compute vertical max for both
void kernel_maxpool2d_s8(const int8_t *input, int8_t *output, int N, int C, int IH, int IW, int KH, int KW, int SH, int SW, int PH, int PW, int DH, int DW)
{
    int OH = (IH + 2*PH - DH*(KH-1) - 1) / SH + 1;
    int OW = (IW + 2*PW - DW*(KW-1) - 1) / SW + 1;
    
    // MBP path only for 2x2 stride 2, no padding/dilation, IW multiple of 8, and all accesses aligned
    int use_mbp = (PH == 0 && PW == 0 && DH == 1 && DW == 1 && KH == 2 && KW == 2 && SH == 2 && SW == 2 && 
                   IW % 8 == 0 && MB_PEXT_ALIGNED8(input) && MB_PEXT_ALIGNED8(output));
    if (use_mbp) {
        // Quick check: all input/output rows aligned?
        size_t input_row_stride = IW;
        size_t output_row_stride = OW;
        if (input_row_stride % 8 != 0 || output_row_stride % 8 != 0) {
            use_mbp = 0;
        }
    }
    
    if (!use_mbp) {
        // Scalar reference
        for (int n = 0; n < N; ++n) {
            for (int c = 0; c < C; ++c) {
                for (int oh = 0; oh < OH; ++oh) {
                    for (int ow = 0; ow < OW; ++ow) {
                        int8_t max_val = INT8_MIN;
                        for (int kh = 0; kh < KH; ++kh) {
                            int ih = oh * SH - PH + kh * DH;
                            if (ih < 0 || ih >= IH) continue;
                            for (int kw = 0; kw < KW; ++kw) {
                                int iw = ow * SW - PW + kw * DW;
                                if (iw < 0 || iw >= IW) continue;
                                int8_t val = input[((n * C + c) * IH + ih) * IW + iw];
                                if (val > max_val) max_val = val;
                            }
                        }
                        output[((n * C + c) * OH + oh) * OW + ow] = max_val;
                    }
                }
            }
        }
        return;
    }
    
    // MBP path: all addresses are 8-byte aligned, IW multiple of 8, OH even
    for (int n = 0; n < N; ++n) {
        for (int c = 0; c < C; ++c) {
            const int8_t *in_channel = input + ((n * C + c) * IH) * IW;
            int8_t *out_channel = output + ((n * C + c) * OH) * OW;
            
            // Process two output rows at a time to reuse loaded input rows
            for (int oh = 0; oh < OH; oh += 2) {
                int ih0 = oh * 2;
                int ih1 = ih0 + 1;
                int ih2 = ih0 + 2;
                int ih3 = ih0 + 3;
                const int8_t *row0 = in_channel + ih0 * IW;
                const int8_t *row1 = in_channel + ih1 * IW;
                const int8_t *row2 = in_channel + ih2 * IW;
                const int8_t *row3 = in_channel + ih3 * IW;
                int8_t *out_row0 = out_channel + oh * OW;
                int8_t *out_row1 = out_channel + (oh + 1) * OW;
                
                // Process 8 input columns at a time -> 4 output columns per row
                for (int ow = 0; ow < OW; ow += 4) {
                    int iw = ow * 2;
                    // Load two groups from four rows
                    int64_t v00 = MB_PEXT_LD8(row0 + iw);
                    int64_t v01 = MB_PEXT_LD8(row1 + iw);
                    int64_t v10 = MB_PEXT_LD8(row2 + iw);
                    int64_t v11 = MB_PEXT_LD8(row3 + iw);
                    
                    // Vertical max for first output row
                    int64_t vmax0 = mb_pext_max8(v00, v01);
                    // Vertical max for second output row
                    int64_t vmax1 = mb_pext_max8(v10, v11);
                    
                    // Horizontal max of adjacent pairs within each 8-byte group
                    int64_t shifted0 = (int64_t)((uint64_t)vmax0 >> 8);
                    int64_t horiz0 = mb_pext_max8(vmax0, shifted0);
                    int64_t shifted1 = (int64_t)((uint64_t)vmax1 >> 8);
                    int64_t horiz1 = mb_pext_max8(vmax1, shifted1);
                    
                    // Store four output bytes per row
                    out_row0[ow]   = (int8_t)(horiz0 & 0xFF);
                    out_row0[ow+1] = (int8_t)((horiz0 >> 16) & 0xFF);
                    out_row0[ow+2] = (int8_t)((horiz0 >> 32) & 0xFF);
                    out_row0[ow+3] = (int8_t)((horiz0 >> 48) & 0xFF);
                    
                    out_row1[ow]   = (int8_t)(horiz1 & 0xFF);
                    out_row1[ow+1] = (int8_t)((horiz1 >> 16) & 0xFF);
                    out_row1[ow+2] = (int8_t)((horiz1 >> 32) & 0xFF);
                    out_row1[ow+3] = (int8_t)((horiz1 >> 48) & 0xFF);
                }
            }
        }
    }
}
### Hardware in the loop feedback: cycles measured on the FPGA

Every round, the best kernel so far is also run on the actual board: a Rocket RV64 core at 40 MHz with the MBP extension, cycles by rdcycle.  Spike, which scores your candidates, charges one cycle per instruction and has no memory timing; the board pays real latency for every load and store, so a kernel with fewer, wider memory accesses gains more on the board than spike shows.  Optimize for the board's numbers below.

- reference kernel on the FPGA: 1,936,299 cycles (118.2 per output)
- round 1's best kernel: 109,974 cycles on the FPGA (6.7 per output, 17.6x faster than the reference); spike said 72,325; with the MBP instructions replaced by software it takes 1,154,186, so the MBP gives it 10.5x.
